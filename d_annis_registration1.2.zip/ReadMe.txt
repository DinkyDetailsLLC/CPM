
Dan Annis
CPM 0414

Week 1
Parse User Application with Login, Registration, Creation, And Display
https://github.com/DinkyDetailsLLC/CPM/tree/master/MyHairDid_v1.2



***** Instructions **********

Sign up using the registration. 
Once Signed in, start creating events. 
When done, go to the menu and log out

Thats it!

