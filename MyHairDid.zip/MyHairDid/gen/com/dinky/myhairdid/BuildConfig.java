/** Automatically generated file. DO NOT MODIFY */
package com.dinky.myhairdid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}