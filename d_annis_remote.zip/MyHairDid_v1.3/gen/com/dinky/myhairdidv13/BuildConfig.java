/** Automatically generated file. DO NOT MODIFY */
package com.dinky.myhairdidv13;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}